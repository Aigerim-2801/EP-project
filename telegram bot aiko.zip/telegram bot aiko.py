import telebot
bot = telebot.TeleBot("1281532935:AAE3tIp5JF5pSUyJ3o2Be49tIUCfE3mY-1g")
keyboard1 = telebot.types.ReplyKeyboardMarkup()
keyboard1.row('Karynzharyk', 'Bozzhyra', 'Beket-Ata', 'Blue Bay', 'Sherkala', 'Tuzbair', 'Map', 'Route', 'Thank you')

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Hi there, I am MangystauTour_bot.'
                                      'You can find out a lot of useful  information about the most beautiful and historical places of the Mangistau region.', reply_markup=keyboard1)

@bot.message_handler(content_types=['text'])
def send_text(message):
    if message.text.lower() == 'karynzharyk':

       bot.send_message(message.chat.id, 'Information:                                                                                    '
       
       '• Karynzharyk is a desert depression between the Mangystau Peninsula and Ustyurt. Located on the territory of the Karakiyansky district of the Mangystau region. It stretches from north to south-west for 130-160 km, width 24-40 km. The area is 2 thousand km². Some places have turned into salt lakes, salt marshes. Its bottom is covered by the longest Kenderli sor in Mangystau region.The climate is continental, the average January temperature is 5-6 ° С, July 27 ° С.')
       bot.send_message(message.chat.id, 'The opinions of tourists who have visited Karynzharyk:                                                                                           '
                                         
                                         '• I am amazed at the unprecedented beauty and scale of this place. Its endless expanses and salt silence. To feel this, you must definitely go there.                                                                     '
                                         
                                         '• The expedition surpassed any wildest expectations!                                     '
                                         
                                         '• Stunning views, pioneering spirit, team cohesion, thoughtful route - everything is at its best!                                                               '
                                         
                                         '• After all, surprisingly, NO ONE had a single drop of displeasure. It is just a wonderful end to the day!')

       bot.send_photo(message.chat.id, 'http://isostan.com/Best1/31.jpg')

       bot.send_photo(message.chat.id, 'https://allmangystau.kz/wp-content/uploads/2020/03/karynzharyk3.jpg')

    elif message.text.lower() == 'bozzhyra':
        bot.send_message(message.chat.id, 'Information:                                                                                  '
                                          
                                          '• Bozzhyra is a section of the chink (side) of the Ustyurt plateau, where Mother Nature gave complete freedom to her imagination, creating an unearthly landscape in white. It is located in the Karakiya district of the Mangistau region, 300 km from the city of Aktau. Height - 250 m.')
        bot.send_message(message.chat.id,'Interesting fact:                                                                                       '
                                         
                                         '• This monument was included in the list of sacred objects under the project of regional significance "Sacred Geography of Kazakhstan" within the framework of the program "Looking into the future: modernization of public consciousness".                                                                            '
                                        
                                         '• The foot of the "fangs" is the most famous point of Boszhira. Tourists rush here first of all.                                                       '
                                         
                                         '• The rocks, like chameleons, change their appearance depending on the lighting. The beige color predominates, but interlayers of brown, pink, gray, white and yellow can be seen.                                                                  '
                                         
                                         '• Seeing the chalk mountains lit by moonlight is a special piece of luck.                                                                                                  '
                                         
                                         '• Here you can shoot Hollywood westerns or science fiction films. It seems that these landscapes are of alien origin. But in fact, they were once the bottom of the ancient Tethys Ocean. This incredible landscape was created by nature.')
        bot.send_message(message.chat.id,'The opinion of tourists who visited Bozzhyra:                                                                                '
                                         
                                         '• The view was just alien! In other matters, it is with these words that people describe what they saw: Mars, space ... And some acquaintances even assumed that it was America.                                                                                                '
                                         
                                         '• Well, we have another shock from what we saw. A huge ship is sailing down the valley! Or maybe a dinosaur put its crest on the surface, or the spikes of a magic castle ... Choose who you like! If you look closely, you will see several camps at the foot of the mountain. This place is so popular among tourist travelers!')

        bot.send_photo(message.chat.id,'http://rasfokus.ru/images/photos/medium/69f9badb105882a8451f5f68e73d45ff.jpg')

        bot.send_photo(message.chat.id,'https://earth-chronicles.com/wp-content/uploads/2016/10/468227.jpg')



    elif message.text.lower() == 'beket-ata':
        bot.send_message(message.chat.id,
                         'Information:                                                                                  '

                         '• Beket-ATA underground mosque is located on the border of the Ustyurt plateau.                                                                               '  
                         
                         '•It was built in the 17th century.                                                                                     '
                         
                         '•Beket-ATA is known not only in Mangistau, it is known and revered by the entire Islamic world. He was a spiritual educator and leader, a humanist, a great Saint.                                        '
                         
                         '•The distance from the nearest Senec settlement is 115 kilometers. And from the nearest city of Zhanaozen to the mosque about 150 kilometers.                                                                                 '                                                                 
                         
                         '•It was founded by one of the most revered Kazakh religious figures and preachers of Sufism Beket-ATA, who during his lifetime was famous for the gift of healing not only the body, but also the soul.                                                                                          '
                         
                         '•The Saints grave is located right in the mosque. This is a place with a special energy. Believers say that after visiting the necropolis, real miracles happen to them.')


        bot.send_message(message.chat.id,
                         'Interesting facts:                                                                                       '

                         '•The mosques location is a special feature: to get inside, visitors go down to the ground about 1,500 meters. The Russian version of National Geographic included the mosque in the list of five wonders of Kazakhstan. The list also includes natural beauty and architectural monuments of Mangystau, which are recommended for tourists to visit.                                                                   '
                         
                         '•The Beket-ATA mosque is called the pearl of the architectural and construction art of Mangistau.                                                           '
                         
                         '•Before the visit, pilgrims tend to visit the Shopan-ATA mosque, another important cultural monument that is located on the way to the Beket-ATA necropolis.                                                            '
                         
                         '•The voice sounds different in every room.                                                                '
                         
                         '•But not everyone can overcome the road to the Shrine. They say that Beket-ATA does not accept some people, but the time has not yet come for others. They say that once two women, mother-in-law and daughter-in-law, went to the mosque of the elder. The women couldnt stand each other, and they were fighting all the way. Their car broke down halfway, and they had to change to another car that was going in the opposite direction: there was no other transport. So, the road to the Shrine did not work out for relatives, but for people with good intentions, the path is easy and without obstacles.                                                       '
                         
                         '•The mosque consists of only four rooms, in one of them the Saint himself is buried. In another room, the ashes of Akkuash, his sister, are placed, only women who can tell about their difficulties and ask for help are allowed here. The third room holds the staff of Beket-ATA. The fourth room houses pilgrims for prayer.                                                                                                    '
                         
                         '•The road to the underground mosque of Beket-ATA runs through the Ustyurt plateau. Near the mosque there is a spring, from which, they say, the Saint himself took water. You can often see saigas, foxes, wild goats, and ROE deer near the spring. These animals are considered sacred here, pilgrims try not to approach them, Beket-ATA himself, as the legends say, forbade hunting in the vicinity.')

        bot.send_message(message.chat.id,
                         'Travelers:                                                                                '

                         '•For a long time, only believers came here. Now the mosque has become one of the places of the tourist route along the Ustyurt plateau. At the same time, you should know that it is forbidden to take photos or video inside the mosque. The Beket-ATA complex also includes the so-called travelers House, where you can stay for the night.                                                                              '
                         
                         '•All year round in Oglandy attracts thousands of pilgrims. People come to worship the Holy places not only from different cities of Kazakhstan, but also from Europe and Asia.')

        bot.send_photo(message.chat.id, 'https://uniworld.ru/images/pics/329.jpg')



    elif message.text.lower() == 'blue bay':
        bot.send_message(message.chat.id,
                         'Information:                                                                                  '

                         '• Blue Bay beach in Kazakhstan is located near the waters of the Caspian sea. This is one of the local attractions and a favorite place for all tourists.                                                                          '
                         
                         '• Blue Bay beach is located in the South-West of the Mangyshlak Peninsula, about 80 kilometers from the city of Aktau, on the way to the city of Fort Shevchenko. Cape Sagyndyk is located 15 kilometers South of the Bay.                                                          '
                         
                         '• The purest sea water washes the Golden sand of the coast. In hot and Sunny weather, the Caspian sea gets a rich turquoise hue. When clouds are found over the beach, it rains and the wind blows, the sea water turns leaden.                                                            '
                         
                         '• In the Blue Bay area, wild plants and shrubs grow in spring and summer, and there is a lot of wormwood that fills the air with its smell. In autumn, you can pick berries and wild plants here.                                                                                                               '
                         
                         '• The deserted beach attracts many animals. Snakes, turtles, lizards, and monitor lizards are common. You can see a herd of wild horses, gazelles, and saigas grazing near the Bay. Blue Bay — "transit point" for birds: swans, wild geese and ducks.')

        bot.send_message(message.chat.id,
                         'Interesting facts:                                                                                       '

                         '•One of the local attractions of Blue Bay beach is a rocky formation that protrudes above the sea. It is called the rock - "Devil s finger". This interesting natural object is located 500 meters from the Bay, about a 10-minute walk away.                                                '
                         
                         '•There is a legend about the "Devil s finger": if you find the right point on the shore and slowly move to the side, you can see a human face in the outline of this rock. If you look at the "Devil s finger" and change your position, looking at the outline of the mountain, the human face will be sad from one point, and happy from the other.                                                                                      '
                         
                         '•The water in this place is often crystal clear.')
        bot.send_message(message.chat.id,
                         'Opinions of ravelers:                                                                                '

                         '•I went to explore the rocks and sand dunes that protect the beach from prying eyes. On the rocks I found beautiful steppe Agamas, on the dunes all the same water snakes, in short, there was something to do besides swimming in the sea-okiyane.                                                 '
                         
                         '•Blue Bay sea and beach were beautiful.Mangistau turned out to be quite a large and very decent city.')


        bot.send_photo(message.chat.id, 'http://rasfokus.ru/images/photos/medium/a04fd2f4c60985dc802646cff00fa48f.jpg')



    elif message.text.lower() == 'sherkala':
        bot.send_message(message.chat.id,
                         'Information:                                                                                  '

                         '•Sherkala-a lonely mountain of unusual shape, about 94 km North-East of the city of Aktau, 18 km from the village of Shetpe.                                               '
                         
                         '•The height of the mountain is 307 meters.                                      '
                         
                         '•The canyons show that there used to be mountain rivers and waterfalls. The depth of some of them reaches 70-100 meters.                                             '
                         
                         '•Sherkala is considered one of the shrines of Mangystau.                                        ' 
                         
                         '•A popular tourist destination.                                          '
                         
                         '•There is a green oasis near Shergala. This is a spring and a small river Akmysh. Here, in the shade of ancient trees, under the ringing trills of birds, it is pleasant to sit and listen to the story of the Mangyshlak settlement. It was built on the route of the caravan route that was used for trade between Bukhara and the Northern lands centuries ago. This city was burned down several centuries ago.')

        bot.send_message(message.chat.id,
                         'Interesting facts:                                                                                       '

                         '•If you look at it from one side, the mountain looks like a huge white Yurt, but on the other — Sherkala looks like a sleeping lion with its huge head on its paws. That s why they called the mountain Shergala, which means "lion mountain" or "Lion mountain" in Turkmen.                                                                                         '
                          
                         '•There is a popular belief that if you make a wish before going around Shergala, it will come true. But the main thing — for each bend, for a new turn, an amazing view opens up, so unusual that sometimes it seems that you are on an uninhabited planet.                                                                                                                                 '
                         
                         '•Locals believe that you can not go into the caves of the mountain — there are sacred spirits. Some believe that the spirits are the very defenders of the fortress, who are forever hidden in caves from their invaders.')

        bot.send_message(message.chat.id,
                         'Opinions of ravelers:                                                                                '

                         '•Sherkala. The more I watch, the more I like it all ...                                 '

                         '•What an amazing variety!                                                                        '

                         '•Fantastic location!')

        bot.send_photo(message.chat.id, 'https://www.tourasia.kz/wp-content/uploads/usturt_6.jpg')
        bot.send_photo(message.chat.id, 'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1RkzJA5--rjHlHMFwcdB9-xB6aKTM5SRkZCeTgDn6uOyic')


    elif message.text.lower() == 'tuzbair':
        bot.send_message(message.chat.id,
                     'Information:                                                                                  '

                     '•Tuzbair is a rocky area and salt marsh in the Mangistau region in South-Eastern Kazakhstan, near the large Ustyurt plateau.                                          '
                     
                     '•Mangystau district is an amazing landscape: snow-white salt marshes and limestone mountains against a blue sky and yellowish-brown soil.                                                                              '
                     
                     '•Despite the wild steppe nature, the area is not difficult to reach — you can get to Tuzbair by almost any car in a short time.                                        '

                     '•The best time to visit Tuzbair is the second half of April and may. The steppe blooms at this time — there are fields of wild tulips everywhere, and the air temperature is kept at a tolerable level.                                                                                                            '

                     '•In summer, the heat here reaches +40...+45 degrees.                                                                  '
                     
                     '•In winter, cold winds blow with sand and limestone dust.                                     '
                     
                     '•In autumn, the weather is also quite mild, but the steppe grasses are dry, and the area does not look as picturesque as in spring.')

        bot.send_message(message.chat.id,
                     'Interesting facts:                                                                                       '

                     '•The main attraction of tuzbair is the salt marsh of The same name. In Kazakh, it is called "SOR", which means a type of salt marsh that has no runoff and is shallow.                                          '
                       
                     '•In the summer, the crust hardens, you can walk freely — occasionally your feet will fall into the salt deposits to a depth of 10-15 centimeters. Therefore, to walk on the surface of the salt marsh, you need to wear rubber boots or other waterproof shoes with a high top. Or as an option — to walk barefoot.                                           '
                     
                     '•Supply of drinking water - from 3 to 5 liters per day per person.                                              '
                     
                     '•Also, in Sunny weather, you need to wear sunglasses — looking at the snow-white limestone mountains is harmful to the eyes.')



        bot.send_message(message.chat.id,
                     'Opinions of ravelers:                                                                                '

                     '•Some tourists believe that the warm salt crust has a beneficial effect on the body.                                                             '
                    
                     '•The terrain is diverse and impresses even experienced travelers: rocky cliffs, eroded remnants, salt marshes, steppe.                                                                   '
                     
                     '•Here you can watch the scenery under different lighting conditions-in the soft morning and in the bright daytime, Golden sunset light, and also see the outlines of rocks under the starry sky.                                                                                     '
                     
                     '•We stopped at a small area at the foot of the white mountains. On the one hand, their slopes towered above us, relief and artfully cut, most likely by rain streams, and on the other — at a distance of only a couple of dozen meters, a small slope ending in a cliff.')


        bot.send_photo(message.chat.id, 'https://silktravel.kz/wp-content/uploads/2018/11/IMG_3740-2.jpg')
        bot.send_photo(message.chat.id, 'https://img.tourister.ru/files/2/2/7/8/7/4/1/0/clones/870_650_fixedwidth.jpg')


    elif message.text.lower() == 'map':
        bot.send_photo(message.chat.id, 'https://www.drz-club.ru/_fr/97/2274210.jpg')

    elif message.text.lower() == 'route':
        bot.send_message(message.chat.id, 'https://www.toopics.com/compasstrip.kz/?lang=ru')
        bot.send_message(message.chat.id, 'https://instagram.com/compasstrip.kz?igshid=1gbzgibkx522g')

    elif message.text.lower() == 'thank you':
        bot.send_sticker(message.chat.id, 'CAADAgADZgkAAnlc4gmfCor5YbYYRAI')

@bot.message_handler(content_types=['sticker'])
def sticker_id(message):
    print(message)
bot.polling()
